var canvas = document.getElementById("GameCanvas");
var ctx = canvas.getContext('2d');
var centerX = canvas.width / 2;
var centerY = canvas.height / 2;

// 별 그리기 함수
function drawStar(x, y, outerRadius, innerRadius, points, rotation) {
    ctx.beginPath();
    ctx.fillStyle = "rgb(225, 201, 14)";
    ctx.moveTo(x + outerRadius * Math.cos(rotation), y + outerRadius * Math.sin(rotation));
    for (var i = 0; i < points * 2; i++) {
        var radius = i % 2 === 0 ? outerRadius : innerRadius;
        var angle = (Math.PI / points) * i + rotation; // 회전값을 각도에 추가
        ctx.lineTo(x + radius * Math.cos(angle), y + radius * Math.sin(angle));
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
}

// 하트 그리기 함수
function drawHeart(x, y, size) {
    ctx.beginPath();
    ctx.fillStyle = "red";
    ctx.moveTo(x, y + size / 2);
    ctx.bezierCurveTo(x, y, x - size / 2, y, x - size / 2, y + size / 2);
    ctx.bezierCurveTo(x - size / 2, y + size / 2, x - size / 2, y + size, x, y + size);
    ctx.bezierCurveTo(x, y + size, x + size / 2, y + size, x + size / 2, y + size / 2);
    ctx.bezierCurveTo(x + size / 2, y, x, y, x, y + size / 2);
    ctx.closePath();
    ctx.fill();
}

// 캔버스의 중앙에 별 그리기
var outerRadius = 10; // 외부 반지름
var innerRadius = 4; // 내부 반지름
var points = 5; // 별의 총 점의 수 (5각 별)
var rotation = Math.PI / 4; // 회전값 (45도)

drawStar(centerX, centerY, outerRadius, innerRadius, points, rotation);

// f5 키 눌렀을 때 이벤트 처리
document.addEventListener('keydown', function(event) {
    if (event.key === "F5") {
        // 캔버스를 클리어하여 이전 그림을 지움
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // 캔버스의 중앙에 별 그리기
        drawStar(centerX, centerY, outerRadius, innerRadius, points, rotation);
        
        // 랜덤 위치에 하트 그리기
        var heartSize = 20; // 하트 크기
        var randomX = Math.random() * (canvas.width - heartSize);
        var randomY = Math.random() * (canvas.height - heartSize);
        drawHeart(randomX, randomY, heartSize);
    }
});

// 초기에 하트 하나를 화면에 그림
var initialHeartSize = 20; // 초기 하트 크기
var initialRandomX = Math.random() * (canvas.width - initialHeartSize);
var initialRandomY = Math.random() * (canvas.height - initialHeartSize);
drawHeart(initialRandomX, initialRandomY, initialHeartSize);

//---------------------------------------------------------------------------------------------------------------------------------

var GameTitle = document.getElementById("GameTitle");
var ctx = GameTitle.getContext('2d');
var centerX = GameTitle.width / 2;
var centerY = GameTitle.height / 2;

var button = document.getElementById('changeCanvas');
var text = document.getElementById('Text');

button.addEventListener('click', function() {
    setTimeout(function(){
        GameTitle.style.display = 'none';
        text.style.display = 'none';
        button.style.display = 'none';
    }, 1000)
});

//---------------------------------------------------------------------------------------------------------------------------------

// 초록색 원 그리기 함수
function drawCircle(x, y, radius) {
    ctx.beginPath();
    ctx.fillStyle = "green";
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.closePath();
    ctx.fill();
}

// 초록색 원의 초기 위치 및 속도 설정
var greenCircles = [];
function createGreenCircles() {
    for (var i = 0; i < 4; i++) {
        var circle = {
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            radius: Math.random() * 5 + 1, // 반지름은 1에서 5 사이의 랜덤한 값
            speed: Math.random() * 3 + 1, // 속도는 1에서 3 사이의 랜덤한 값
            direction: Math.random() * Math.PI * 2 // 이동 방향은 랜덤하게 설정
        };
        greenCircles.push(circle);
    }
}

// 초록색 원 이동 함수
function moveGreenCircles() {
    greenCircles.forEach(function(circle) {
        circle.x += Math.cos(circle.direction) * circle.speed;
        circle.y += Math.sin(circle.direction) * circle.speed;
        
        // 캔버스 경계를 넘어가면 반대편으로 이동하도록 처리
        if (circle.x < 0) {
            circle.x = canvas.width;
        } else if (circle.x > canvas.width) {
            circle.x = 0;
        }
        
        if (circle.y < 0) {
            circle.y = canvas.height;
        } else if (circle.y > canvas.height) {
            circle.y = 0;
        }
    });
}

// 초록색 원 그리기 함수 호출
function drawGreenCircles() {
    greenCircles.forEach(function(circle) {
        drawCircle(circle.x, circle.y, circle.radius);
    });
}

// 초록색 원 생성 및 이동 함수 호출
function startGreenCirclesAnimation() {
    createGreenCircles();
    
    // 초록색 원 이동 및 다가오도록 설정
    setInterval(function() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // 별 그리기
        drawStar(centerX, centerY, outerRadius, innerRadius, points, rotation);
        
        // 초록색 원 이동
        moveGreenCircles();
        
        // 초록색 원 그리기
        drawGreenCircles();
    }, 30);
}

// 시작 버튼을 클릭할 때 실행되는 함수
button.addEventListener('click', function() {
    setTimeout(function(){
        GameTitle.style.display = 'none';
        text.style.display = 'none';
        button.style.display = 'none';
        
        // GameCanvas가 보일 때에만 초록색 원 생성 및 애니메이션 실행
        if (GameCanvas.style.display !== 'none') {
            startGreenCirclesAnimation();
        }
    }, 1000)
});

// GameCanvas가 보일 때에만 초록색 원 생성 및 애니메이션 실행
if (GameCanvas.style.display !== 'none') {
    createGreenCircles();
    startGreenCirclesAnimation();
}

