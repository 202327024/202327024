document.getElementById('gameCanvas').style.display = 'none';
document.getElementById('ReplayCanvas').style.display = 'none';

var canvas = document.getElementById('gameCanvas');
var ctx = canvas.getContext('2d');

var hpScoreElement = document.getElementById('hpscore');
var gameoverint = document.getElementById('deathscore');
var hp = parseInt(hpScoreElement.innerText);
var gameInterval;
var createBallsInterval;
var starRotation = 0; // 별의 회전 각도
var starSpeed = 2; // 별의 이동 속도
var star = { x: canvas.width / 2, y: canvas.height / 2, radius: 20, dx: 0, dy: 0 }; // 별 객체

var waves = []; // 파동을 저장할 배열

function drawStar(line) {
    ctx.save(); // 현재 상태 저장
    ctx.translate(star.x, star.y); // 별의 중심으로 이동
    ctx.rotate(starRotation); // 별을 회전
    ctx.translate(-star.x, -star.y); // 원래 위치로 이동
    var centerX = star.x;
    var centerY = star.y;
    var outerRadius = line;
    var innerRadius = line / 2;
    var numPoints = 5;
    var angle = Math.PI / numPoints;

    ctx.beginPath();
    for (var i = 0; i < numPoints * 2; i++) {
        var radius = i % 2 === 0 ? outerRadius : innerRadius;
        ctx.lineTo(centerX + radius * Math.cos(i * angle), centerY + radius * Math.sin(i * angle));
    }
    ctx.closePath();
    ctx.strokeStyle = '#000';
    ctx.fillStyle = 'yellow';
    ctx.stroke();
    ctx.fill();
    ctx.restore(); // 이전 상태 복원
}

function drawHeart(moveX, moveY) {
    ctx.beginPath();
    ctx.arc(200 + moveX, 100 + moveY, 10, (Math.PI / 180) * 180, (Math.PI / 180) * 45, false);
    ctx.lineTo(190 + moveX, 125 + moveY);
    ctx.arc(180 + moveX, 100 + moveY, 10, (Math.PI / 180) * 135, (Math.PI / 90) * 0, false);
    ctx.closePath();
    ctx.strokeStyle = '#000';
    ctx.fillStyle = 'red';
    ctx.stroke();
    ctx.fill();
}

function randomizeHeartPosition() {
    moveX = Math.random() * (canvas.width - 400) + 200; // 캔버스 내의 랜덤 위치
    moveY = Math.random() * (canvas.height - 200) + 100;
}

var balls = [];

function drawBall(x, y) {
    ctx.beginPath();
    ctx.arc(x, y, 5, 0, Math.PI * 2, false);
    ctx.fillStyle = 'black';
    ctx.fill();
    ctx.closePath();
}

function getRandomPosition() {
    var x, y;
    var side = Math.floor(Math.random() * 4);
    switch (side) {
        case 0: // top
            x = Math.random() * canvas.width;
            y = -10;
            break;
        case 1: // right
            x = canvas.width + 10;
            y = Math.random() * canvas.height;
            break;
        case 2: // bottom
            x = Math.random() * canvas.width;
            y = canvas.height + 10;
            break;
        case 3: // left
            x = -10;
            y = Math.random() * canvas.height;
            break;
    }
    return { x: x, y: y };
}

function checkCollision(ball) {
    var dx = ball.x - star.x;
    var dy = ball.y - star.y;
    var distance = Math.sqrt(dx * dx + dy * dy);

    return distance < star.radius + 5; // 별과 공이 닿았는지 확인
}

function checkHeartCollision() {
    var dx = (200 + moveX) - star.x;
    var dy = (100 + moveY) - star.y;
    var distance = Math.sqrt(dx * dx + dy * dy);

    if (distance < star.radius + 10) { // 별과 하트가 닿았는지 확인
        if (hp < 3) {
            hp += 1;
            hpScoreElement.innerText = hp;
        }
        randomizeHeartPosition(); // 하트의 위치 재배치
    }
}

function drawWave(wave) {
    ctx.save();
    ctx.translate(wave.x, wave.y);
    ctx.rotate(wave.rotation);
    ctx.translate(-wave.x, -wave.y);

    var centerX = wave.x;
    var centerY = wave.y;
    var outerRadius = wave.radius;
    var innerRadius = wave.radius / 2;
    var numPoints = 5;
    var angle = Math.PI / numPoints;

    ctx.beginPath();
    for (var i = 0; i < numPoints * 2; i++) {
        var radius = i % 2 === 0 ? outerRadius : innerRadius;
        ctx.lineTo(centerX + radius * Math.cos(i * angle), centerY + radius * Math.sin(i * angle));
    }
    ctx.closePath();
    ctx.strokeStyle = 'blue';
    ctx.stroke();
    ctx.restore();
}

function animateBalls() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    starRotation += 0.05; // 별을 회전
    star.x += star.dx; // 별의 위치 업데이트
    star.y += star.dy;
    drawStar(20);
    drawHeart(moveX, moveY);
    checkHeartCollision(); // 하트와 충돌 체크

    waves = waves.filter(function(wave) {
        wave.radius += 2;
        drawWave(wave);

        if (wave.radius > canvas.width / 2 && wave.radius > canvas.height / 2) {
            return false; // 파동이 캔버스 가장자리에 닿으면 삭제
        }

        return true;
    });

    balls = balls.filter(function(ball) {
        var dx = (star.x - ball.x) / 100;
        var dy = (star.y - ball.y) / 100;

        ball.x += dx;
        ball.y += dy;

        if (checkCollision(ball)) {
            hp -= 1;
            hpScoreElement.innerText = hp;
            if (hp <= 0) {
                endGame();
                gameoverint.innerText = parseInt(gameoverint.innerText) + 1;
            }
            return false; // 공을 삭제
        }

        for (var i = 0; i < waves.length; i++) {
            var wave = waves[i];
            var waveDx = ball.x - wave.x;
            var waveDy = ball.y - wave.y;
            var waveDistance = Math.sqrt(waveDx * waveDx + waveDy * waveDy);

            if (waveDistance < wave.radius + 5) {
                return false; // 공이 파동에 닿으면 삭제
            }
        }

        drawBall(ball.x, ball.y);
        return true;
    });
}

function createBalls() {
    var numBalls = Math.floor(Math.random() * 11) + 5; // 5 to 15 balls
    for (var i = 0; i < numBalls; i++) {
        var position = getRandomPosition();
        balls.push({ x: position.x, y: position.y });
    }
}

function startGame() {
    hp = 3;
    hpScoreElement.innerText = hp;
    balls = [];
    randomizeHeartPosition();
    waves = [];
    star = { x: canvas.width / 2, y: canvas.height / 2, radius: 20, dx: 0, dy: 0 };
    document.getElementById('ReplayCanvas').style.display = 'none';
    document.getElementById('gameCanvas').style.display = 'block';
    gameInterval = setInterval(animateBalls, 10);
    createBallsInterval = setInterval(createBalls, 1000);
}

function endGame() {
    clearInterval(gameInterval);
    clearInterval(createBallsInterval);
    document.getElementById('gameCanvas').style.display = 'none';
    document.getElementById('ReplayCanvas').style.display = 'block';
}

document.getElementById('StartButton').addEventListener('click', function () {
    setTimeout(function () {
        document.getElementById('StartCanvas').style.display = 'none';
        startGame();
    }, 1000);
});

document.getElementById('ReplayButton').addEventListener('click', function () {
    setTimeout(function () {
        startGame();
    }, 1000);
});

// 키보드 이벤트 리스너 추가
document.addEventListener('keydown', function(event) {
    switch (event.key) {
        case 'ArrowUp':
            star.dy = -starSpeed;
            break;
        case 'ArrowDown':
            star.dy = starSpeed;
            break;
        case 'ArrowLeft':
            star.dx = -starSpeed;
            break;
        case 'ArrowRight':
            star.dx = starSpeed;
            break;
    }
});

document.addEventListener('keyup', function(event) {
    switch (event.key) {
        case 'ArrowUp':
        case 'ArrowDown':
            star.dy = 0;
            break;
        case 'ArrowLeft':
        case 'ArrowRight':
            star.dx = 0;
            break;
    }
});

// 마우스 클릭 이벤트 리스너 추가
canvas.addEventListener('click', function(event) {
    var rect = canvas.getBoundingClientRect();
    var mouseX = event.clientX - rect.left;
    var mouseY = event.clientY - rect.top;
    waves.push({ x: star.x, y: star.y, radius: star.radius, rotation: starRotation });
});
