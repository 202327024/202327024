var canvas = document.getElementById("GameCanvas");
var ctx = canvas.getContext('2d');
var centerX = canvas.width / 2;
var centerY = canvas.height / 2;

// 별 그리기 함수
function drawStar(x, y, outerRadius, innerRadius, points, rotation) {
    ctx.beginPath();
    ctx.fillStyle = "rgb(225, 201, 14)";
    ctx.moveTo(x + outerRadius * Math.cos(rotation), y + outerRadius * Math.sin(rotation));
    for (var i = 0; i < points * 2; i++) {
        var radius = i % 2 === 0 ? outerRadius : innerRadius;
        var angle = (Math.PI / points) * i + rotation; // 회전값을 각도에 추가
        ctx.lineTo(x + radius * Math.cos(angle), y + radius * Math.sin(angle));
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
}

// 하트 그리기 함수
function drawHeart(x, y, size) {
    ctx.beginPath();
    ctx.fillStyle = "red";
    ctx.moveTo(x, y + size / 2);
    ctx.bezierCurveTo(x, y, x - size / 2, y, x - size / 2, y + size / 2);
    ctx.bezierCurveTo(x - size / 2, y + size / 2, x - size / 2, y + size, x, y + size);
    ctx.bezierCurveTo(x, y + size, x + size / 2, y + size, x + size / 2, y + size / 2);
    ctx.bezierCurveTo(x + size / 2, y, x, y, x, y + size / 2);
    ctx.closePath();
    ctx.fill();
}

// 캔버스의 중앙에 별 그리기
var outerRadius = 10; // 외부 반지름
var innerRadius = 4; // 내부 반지름
var points = 5; // 별의 총 점의 수 (5각 별)
var rotation = Math.PI / 4; // 회전값 (45도)

drawStar(centerX, centerY, outerRadius, innerRadius, points, rotation);

// f5 키 눌렀을 때 이벤트 처리
document.addEventListener('keydown', function(event) {
    if (event.key === "F5") {
        // 캔버스를 클리어하여 이전 그림을 지움
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // 캔버스의 중앙에 별 그리기
        drawStar(centerX, centerY, outerRadius, innerRadius, points, rotation);
        
        // 랜덤 위치에 하트 그리기
        var heartSize = 20; // 하트 크기
        var randomX = Math.random() * (canvas.width - heartSize);
        var randomY = Math.random() * (canvas.height - heartSize);
        drawHeart(randomX, randomY, heartSize);
    }
});

// 초기에 하트 하나를 화면에 그림
var initialHeartSize = 20; // 초기 하트 크기
var initialRandomX = Math.random() * (canvas.width - initialHeartSize);
var initialRandomY = Math.random() * (canvas.height - initialHeartSize);
drawHeart(initialRandomX, initialRandomY, initialHeartSize);
