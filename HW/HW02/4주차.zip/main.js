var studentID = 202327024;

function drawNun(num)
{
    ctx.beginPath();
    ctx.strokeStyle="black";
    ctx.lineTo(1010, 20);
    ctx.lineTo(1000, 20);
    ctx.lineTo(1000, 10);
    ctx.lineTo(1000, 20);
    ctx.lineTo(1010, 20);
    ctx.lineTo(1010, 30);
    ctx.lineTo(1010, 10);
    ctx.stroke();
    ctx.closePath();

    ctx.beginPath();
    ctx.strokeStyle="black";
    ctx.lineTo(980, 10);
    ctx.lineTo(990, 10);
    ctx.lineTo(990, 20);
    ctx.lineTo(980, 20);
    ctx.lineTo(990, 20);
    ctx.lineTo(980, 20);
    ctx.lineTo(980, 30);
    ctx.lineTo(990, 30);
    ctx.stroke();
    ctx.closePath();
    
    ctx.beginPath();
    ctx.strokeStyle="black";
    ctx.lineTo(960, 10);
    ctx.lineTo(970, 10);
    ctx.lineTo(970, 30);
    ctx.lineTo(960, 30);
    ctx.lineTo(960, 10);
    ctx.stroke();
    ctx.closePath();

    ctx.beginPath();
    ctx.strokeStyle="black";
    ctx.lineTo(940, 20);
    ctx.lineTo(940, 10);
    ctx.lineTo(950, 10);
    ctx.lineTo(950, 30);
    ctx.stroke();
    ctx.closePath();

    ctx.beginPath();
    ctx.strokeStyle="black";
    ctx.lineTo(920, 10);
    ctx.lineTo(930, 10);
    ctx.lineTo(930, 20);
    ctx.lineTo(920, 20);
    ctx.lineTo(930, 20);
    ctx.lineTo(920, 20);
    ctx.lineTo(920, 30);
    ctx.lineTo(930, 30);
    ctx.stroke();
    ctx.closePath();

    ctx.beginPath();
    ctx.strokeStyle="black";
    ctx.lineTo(900, 10);
    ctx.lineTo(910, 10);
    ctx.lineTo(910, 20);
    ctx.lineTo(900, 20);
    ctx.lineTo(910, 20);
    ctx.lineTo(910, 30);
    ctx.lineTo(900, 30);
    ctx.stroke();
    ctx.closePath();

    ctx.beginPath();
    ctx.strokeStyle="black";
    ctx.lineTo(880, 10);
    ctx.lineTo(890, 10);
    ctx.lineTo(890, 20);
    ctx.lineTo(880, 20);
    ctx.lineTo(890, 20);
    ctx.lineTo(880, 20);
    ctx.lineTo(880, 30);
    ctx.lineTo(890, 30);
    ctx.stroke();
    ctx.closePath();

    ctx.beginPath();
    ctx.strokeStyle="black";
    ctx.lineTo(860, 10);
    ctx.lineTo(870, 10);
    ctx.lineTo(870, 30);
    ctx.lineTo(860, 30);
    ctx.lineTo(860, 10);
    ctx.stroke();
    ctx.closePath();

    ctx.beginPath();
    ctx.strokeStyle="black";
    ctx.lineTo(840, 10);
    ctx.lineTo(850, 10);
    ctx.lineTo(850, 20);
    ctx.lineTo(840, 20);
    ctx.lineTo(850, 20);
    ctx.lineTo(840, 20);
    ctx.lineTo(840, 30);
    ctx.lineTo(850, 30);
    ctx.stroke();
    ctx.closePath();
}

var canvas = document.getElementById("GameScreenCanvas");
var ctx = canvas.getContext('2d');

ctx.beginPath();

ctx.strokeStyle="magenta";
ctx.fillStyle="yellow";
ctx.moveTo(512, 100);
ctx.lineTo(974, 300);
ctx.lineTo(512, 500);
ctx.lineTo(50, 300);
ctx.lineTo(512, 100);
ctx.stroke();
ctx.fill();

ctx.closePath();



drawNun(studentID);
