var canvas = document.getElementById('gameCanvas');
var ctx = canvas.getContext('2d');

    var width = canvas.width;
    var height = canvas.height;
    var sideLength = 300;
    var heightOfTriangle = (Math.sqrt(3) / 2) * sideLength;
    var centerX = width / 2;
    var centerY = height / 2;

    var x1 = centerX;
    var y1 = centerY - (2 / 3) * heightOfTriangle;
    var x2 = centerX - sideLength / 2;
    var y2 = centerY + (1 / 3) * heightOfTriangle;
    var x3 = centerX + sideLength / 2;
    var y3 = centerY + (1 / 3) * heightOfTriangle;

    var angle = 0;
    var color = 'blue';

    function rotatePoint(x, y, centerX, centerY, angle) {
        var cos = Math.cos(angle);
        var sin = Math.sin(angle);
        var dx = x - centerX;
        var dy = y - centerY;
        var xNew = centerX + dx * cos - dy * sin;
        var yNew = centerY + dx * sin + dy * cos;
        return [xNew, yNew];
    }

    function isPointInTriangle(px, py, x1, y1, x2, y2, x3, y3) {
        var area = 0.5 * (-y2 * x3 + y1 * (-x2 + x3) + x1 * (y2 - y3) + x2 * y3);
        var s = 1 / (2 * area) * (y1 * x3 - x1 * y3 + (y3 - y1) * px + (x1 - x3) * py);
        var t = 1 / (2 * area) * (x1 * y2 - y1 * x2 + (y1 - y2) * px + (x2 - x1) * py);
        var u = 1 - s - t;
        return s >= 0 && t >= 0 && u >= 0;
    }

    function drawRotatingTriangle() {
        ctx.clearRect(0, 0, width, height);
        var [x1r, y1r] = rotatePoint(x1, y1, centerX, centerY, angle);
        var [x2r, y2r] = rotatePoint(x2, y2, centerX, centerY, angle);
        var [x3r, y3r] = rotatePoint(x3, y3, centerX, centerY, angle);

        ctx.beginPath();
        ctx.moveTo(x1r, y1r);
        ctx.lineTo(x2r, y2r);
        ctx.lineTo(x3r, y3r);
        ctx.closePath();
        
        ctx.fillStyle = color;
        ctx.fill();
        
        ctx.strokeStyle = 'black';
        ctx.stroke();

        angle += Math.PI / 180;

        requestAnimationFrame(drawRotatingTriangle);
    }

    canvas.addEventListener('click', function(event) {
        var rect = canvas.getBoundingClientRect();
        var mouseX = event.clientX - rect.left;
        var mouseY = event.clientY - rect.top;

        var [x1r, y1r] = rotatePoint(x1, y1, centerX, centerY, angle);
        var [x2r, y2r] = rotatePoint(x2, y2, centerX, centerY, angle);
        var [x3r, y3r] = rotatePoint(x3, y3, centerX, centerY, angle);

        if (isPointInTriangle(mouseX, mouseY, x1r, y1r, x2r, y2r, x3r, y3r)) {
            color = 'red';
        }
    });

    drawRotatingTriangle();