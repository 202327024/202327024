var canvas = document.getElementById("GameScreenCanvas");
var ctx = canvas.getContext("2d");

var colors = ["#C7C5FF", "black", "blue", "magenta", "pink", "cyan", "orange"]; 

class Heart {
    constructor(colorIndex, size, positionX, positionY, rotate) {
        this.color = colors[colorIndex];
        this.size = size;
        this.positionX = positionX;
        this.positionY = positionY;
        this.rotate = rotate; // 회전 각도
    }
    draw() {
        ctx.save();
        ctx.beginPath();
        ctx.translate(this.positionX, this.positionY);
        ctx.rotate(this.rotate); // 회전
        ctx.scale(this.size, this.size);
        ctx.arc(0.25, -0.25, 0.25, Math.PI * 2, 20);
        ctx.arc(0.65, -0.25, 0.25, Math.PI * 2, 20);
        ctx.lineTo(0.884, -0.13);
        ctx.lineTo(0.45, 0.3);
        ctx.lineTo(0.024, -0.13);
        ctx.closePath();
        ctx.fillStyle = this.color;
        ctx.fill();
        ctx.restore();
    }
}

var hearts = []; // 하트 객체들을 저장할 배열
var heartCount = 0; // 생성된 하트 개수

function render() {
    ctx.clearRect(0, 0, canvas.width, canvas.height); // 캔버스 초기화

    // 0.2초마다 하트 생성
    if (heartCount < 100 && Math.random() < 0.05) { // 5% 확률로 하트 생성
        var newHeart = new Heart(
            Math.round(Math.random() * 6), // 색상 인덱스
            Math.random() * 50 + 20, // 크기 (20 ~ 70)
            Math.random() * (canvas.width - 100) + 50, // x 위치
            Math.random() * (canvas.height - 100) + 50, // y 위치
            Math.random() * Math.PI * 2 // 랜덤한 회전 각도 (0부터 2π)
        );
        hearts.push(newHeart); // 생성된 하트 배열에 추가
        heartCount++; // 생성된 하트 개수 증가
    }

    // 하트 그리기
    hearts.forEach(function(heart) {
        heart.draw();
    });

    requestAnimationFrame(render);
}

render();













