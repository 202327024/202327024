var canvas = document.getElementById("GameScreenCanvas");
var ctx = canvas.getContext("2d");

var PI = Math.PI;

var sunAngle = 0;
var earthAngle = 0;
var moonAngle = 0;

var sunSpeed = PI / 300;   
var earthSpeed = PI / 180; 
var moonSpeed = PI / 90;   

ctx.translate(canvas.width/2, canvas.height/2);

function drawSun() {
    ctx.fillStyle = "yellow";
    ctx.beginPath();
    ctx.arc(0, 0, 50, 0, 2 * Math.PI);
    ctx.fill();
}

function drawEarth() {
    ctx.fillStyle = "blue";
    ctx.beginPath();
    ctx.arc(150 * Math.cos(earthAngle), 150 * Math.sin(earthAngle), 20, 0, 2 * Math.PI);
    ctx.fill();
}

function drawMoon() {
    ctx.fillStyle = "gray";
    ctx.beginPath();
    ctx.arc(40 * Math.cos(moonAngle) + 150 * Math.cos(earthAngle), 40 * Math.sin(moonAngle) + 150 * Math.sin(earthAngle), 10, 0, 2 * Math.PI);
    ctx.fill();
}

function draw() {
    
    sunAngle += sunSpeed;
    earthAngle += earthSpeed;
    moonAngle += moonSpeed;

    ctx.clearRect(-canvas.width/2, -canvas.height/2, canvas.width, canvas.height);
    drawSun();
    drawEarth();
    drawMoon();

    requestAnimationFrame(draw);
}

draw();



/*
var canvas = document.getElementById("GameScreenCanvas");
var ctx = canvas.getContext("2d");

var rotateVar = 0.0;
var PI = 3.14;

ctx.translate(canvas.width/2, canvas.height/2);

function drawRect(angle)
{
    ctx.fillStyle = "magenta";
    ctx.save();
    ctx.rotate(angle);
    ctx.fillRect(-50, -50, 50, 50);
    ctx.restore();
}

var rotAngle = 0;

function draw()
{
    rotAngle += PI/100
    ctx.clearRect(-100, -100, canvas.width, canvas.height);
    drawRect(rotAngle);
    requestAnimationFrame(draw);
}

draw();
*/








